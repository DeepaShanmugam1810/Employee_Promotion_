from django.apps import AppConfig


class PromotionPredictConfig(AppConfig):
    default_auto_field = 'django.db.models.BigAutoField'
    name = 'promotion_predict'
